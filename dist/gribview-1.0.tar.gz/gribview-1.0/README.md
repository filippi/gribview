# gribview

`gribview` is a lightweight cross-platform visualiser for GRIB files that can also filter grib messages. Perfect for a quick “what is in this data” check. 
Under the hood it combines ECMWF ecCodes for decoding, SDL2/OpenGL/GLEW for rendering and Dear ImGui for the UI.

![gribview screenshot](pages/screenshot.jpg)

## Features
- Open one or more GRIB files and browse every message in a sortable, filterable table.
- Display field metadata (levels, parameters, dates, GRIB keys) and dig into the full key/value map through the inspector popup.
- Interactive OpenGL viewer with pan, zoom, auto-fit, manual min/max scaling and switchable colour maps defined in `src/colormap512.h`. Can be re-generated with python script.
- Multi-select rows to keep related messages together, regenerate textures on demand and save PNG captures with `stb_image_write`.
- Export a filtered set of messages to a new GRIB file directly from the UI.
- Drag-and-drop GRIB files onto the window or double-click them in Finder once the app is associated (the bundled macOS app declares `.grib/.grb/.grib2/.grb2` file types so they open directly in gribview).
- File menu with `Open…`, `Clear`, and shortcuts (`Cmd/Ctrl + O`, `Cmd/Ctrl + Shift + W`, `Cmd/Ctrl + Q`) so you can launch empty, load additional GRIBs later, or clear the workspace without restarting.

## Dependencies
| Library | Why it is needed | How to get it |
| --- | --- | --- |
| [ecCodes](https://confluence.ecmwf.int/display/ECC/ecCodes+Home) | Decoding GRIB messages. | `conda install eccodes`, `brew install eccodes`, `apt install libeccodes-dev`, etc. |
| [SDL2](https://www.libsdl.org/) | Windowing, input and GL context creation. | `conda install sdl2`, `brew install sdl2`, `apt install libsdl2-dev`, `choco install sdl2`. |
| [GLEW](http://glew.sourceforge.net/) | Modern OpenGL loader used by ImGui. | `conda install glew`, `brew install glew`, `apt install libglew-dev`, `choco install glew`. |
| [OpenGL 3.2+](https://www.opengl.org/) | Rendering backend. | Installed with the OS/toolchain. |
| [CMake ≥ 3.16](https://cmake.org/) & a C++17 compiler | Build system. | Already bundled with Xcode/Visual Studio, or install via your package manager. |
| [tinyfiledialogs](https://sourceforge.net/projects/tinyfiledialogs/) (bundled) | Native file chooser for `File → Open…`. | Included in `external/tinyfiledialogs`. |

All other third-party sources (Dear ImGui + backends, stb) live inside `external/` and `src/`.

## Prebuilt packages

Every tag named `v*` triggers the release workflow which attaches ready-to-run
artifacts to the corresponding GitHub Release. Grab the latest version from
<https://github.com/filippi/gribview/releases>:

| Platform | Format | Install snippet |
| --- | --- | --- |
| Debian/Ubuntu | `.deb` + tarball | `sudo apt install ./gribview-<version>-Linux.deb` or unpack `gribview-<version>-Linux.tar.gz` and run `bin/gribview`. |
| macOS | Homebrew formula + tarball | `brew tap filippi/gribview && brew install --build-from-source filippi/gribview/gribview`. Portable tarballs remain under the releases page. |
| Windows | `.zip` | Unzip `gribview-<version>-windows.zip` and launch `gribview.exe`. |

Maintainers who cut releases or need additional packaging details can follow
`docs/packaging.md`.

## Building

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

The executable is written to `build/bin/gribview` (or `build/bin/Release/gribview.exe` on Windows). `build.sh` and `cmake-build.sh` wrap those two commands if you prefer a scriptable workflow.

### macOS
```bash
brew install cmake eccodes sdl2 glew
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

### Ubuntu / Debian
```bash
sudo apt update
sudo apt install build-essential cmake ninja-build libeccodes-dev libsdl2-dev libglew-dev
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build
```

### Windows (Visual Studio + vcpkg or micromamba)
Option 1 – [vcpkg](https://github.com/microsoft/vcpkg):
```powershell
vcpkg install eccodes glew sdl2
cmake -S . -B build -G "Ninja" -DCMAKE_BUILD_TYPE=Release -DCMAKE_TOOLCHAIN_FILE="C:/path/to/vcpkg/scripts/buildsystems/vcpkg.cmake"
cmake --build build --config Release
```

Option 2 – [micromamba](https://github.com/mamba-org/micromamba) (same command works on macOS/Linux too):
```powershell
micromamba create -n gribview cmake ninja eccodes glew sdl2
micromamba activate gribview
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
```

## Running gribview
```bash
./build/bin/gribview file1.grib file2.grib2
```

Launching without arguments is fine as well—use the menu bar (`File → Open…`) or the `Cmd/Ctrl + O` shortcut to browse for one or multiple GRIB files afterwards. Multi-select rows with Shift/Cmd/Ctrl, then click “Save selection” to export only that subset.

Key UI areas:
- **Left panel**: select colour map, auto-fit or lock min/max, export PNGs and trigger rescales.
- **Message table**: shows selected GRIB keys; click headers to sort, right-click to choose additional keys, and multi-select rows to compare related fields.
- **Inspector**: press *More info* on a row to load every available GRIB key/value pair (excluding large arrays).
- **Canvas**: mouse wheel to zoom, drag with the left button to pan. Hold space to temporarily switch to pan mode if multi-selecting rows.
- **Export**: choose `Save selection` to write currently selected messages back to a new `.grib` file.

## Development workflow
- `cmake --build build --target install` installs the binary under `build/bin`.
- Run `ctest --output-on-failure` from the build directory to confirm the build completes (there are no unit tests yet, but this keeps CI paths exercised).
- Code style is standard clang-format defaults from ImGui/STB; keep additions simple and comment only when non-obvious logic appears.

## Packaging (macOS DMG)
The repository bundles a helper script that constructs a standalone `.app` bundle and `.dmg` image so testers can run gribview without compiling dependencies:

```bash
./build.sh                       # produce build/bin/gribview
./tools/make_icon.sh             # optional: regenerate icons from tools/icon.png (requires ImageMagick); script also runs automatically if possible
./tools/package_macos.sh         # creates dist/Gribview.app and dist/Gribview.dmg
open dist/Gribview.dmg
```

The script copies SDL2, GLEW, ecCodes, **including its `definitions/` and `samples/` directories**, into the bundle so no external runtime is required, and rewrites the loader paths. The resulting DMG can be published on GitHub Releases or shared directly; recipients just drag the `Gribview.app` onto their system.
An ad-hoc `codesign --force --deep -` pass is applied automatically so macOS accepts the relocated dylibs; notarisation is still up to you if you plan to distribute broadly.

## Packaging (Homebrew)
`gribview` can also ship as a Homebrew formula. Use `tools/release_homebrew.sh <version>` to tag a release (you need to match `CMakeLists.txt` version), pack the sources into `dist/gribview-<version>.tar.gz`, and rewrite `homebrew/gribview.rb` so it references `https://github.com/filippi/gribview/releases/download/v<version>/gribview-<version>.tar.gz` with the generated SHA256. The script emits the archive path and digest, then you can:

1. `git add dist/gribview-<version>.tar.gz homebrew/gribview.rb`
2. `git commit -m "Release v<version>"`
3. `git push --follow-tags`
4. Create a GitHub release named `v<version>` and attach `dist/gribview-<version>.tar.gz`.

The formula depends on `cmake`, `pkg-config`, `eccodes`, `glew`, and `sdl2`, and uses `cmake --install` to drop the binary under Homebrew prefixes.

Homebrew requires the formula to live in a tap, so installing from `./homebrew/gribview.rb` directly shows `Error: Homebrew requires formulae to be in a tap`. Instead, either create a tap manually or run `tools/homebrew_tap_install.sh`:

```bash
# one-time tap setup (example tap name)
brew tap-new filippi/gribview
# copy the formula into the tap and install (the helper does this for you as well)
mkdir -p "$(brew --repo filippi/gribview)/Formula"
cp homebrew/gribview.rb "$(brew --repo filippi/gribview)/Formula/gribview.rb"
brew install --build-from-source filippi/gribview/gribview
```

Or simply:

```bash
tools/homebrew_tap_install.sh
```

After the tap installs the release formula, you can run `brew reinstall --build-from-source filippi/gribview/gribview` to rebuild against newer dependencies.

## Continuous integration
CI lives in `.github/workflows/build.yml` and builds the project for Linux, macOS and Windows on every push or pull request. Each job:
1. Provisions dependencies with Micromamba on the respective runner.
2. Configures CMake with Ninja in Release mode.
3. Builds the executable and publishes the binaries as workflow artifacts so you can grab the latest snapshot without compiling locally.

## Tutorial / video slot
Drop your forthcoming tutorial video link here when it is ready. Until then, this README acts as the quick-start reference for contributors and users.
